# Dyad Language Repository Artifact

This artifact contains the dyad-lang repository at commit: studio-v0.5.1

## Source
Repository: https://github.com/juliacomputing/dyad-lang.git
Commit: studio-v0.5.1

## License
Please refer to the LICENSE file in the repository for licensing information.

## Attribution
This is a snapshot of the dyad-lang repository for use as a Julia artifact.
