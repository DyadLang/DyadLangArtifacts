
using SampleComponents
using Test
    
include("../generated/tests.jl")