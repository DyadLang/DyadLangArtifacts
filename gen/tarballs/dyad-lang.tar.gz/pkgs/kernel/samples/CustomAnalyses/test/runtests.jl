
using CustomAnalyses
using Test
    
include("../generated/tests.jl")