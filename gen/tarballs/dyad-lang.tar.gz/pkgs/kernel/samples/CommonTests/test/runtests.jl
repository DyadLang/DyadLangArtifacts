
using CommonTests
using Test
    
include("../generated/tests.jl")