module BarComponents

include("../generated/definitions.jl")
include("../generated/experiments.jl")
include("../generated/precompilation.jl")
    
end # module BarComponents