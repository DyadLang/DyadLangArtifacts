# GUI Poke

In this section, I take several different videos and discuss the graphical user
interface. Specifically, I'll comment on what I like and don't like about the
different UIs. At the same time, the videos provide at least some context on
how these types of tools are used to model physical systems.
