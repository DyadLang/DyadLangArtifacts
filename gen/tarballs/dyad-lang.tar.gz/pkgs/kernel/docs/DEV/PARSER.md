---
order: 20
icon: ":world_map:"
---

# Dyad Parser
