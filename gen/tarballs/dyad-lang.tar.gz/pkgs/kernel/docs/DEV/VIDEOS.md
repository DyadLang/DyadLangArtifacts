# Explanatory Videos

I've recorded the following videos that walk through various topics
about the Dyad kernel:

- [Early Dyad (formerly Remodel) Justifications](https://drive.google.com/file/d/1G9SRR5g-Dk-qmYNi1penUVKyJpfq2mas/view?usp=drive_link)
- [Update AST and Parser for New Dyad Feature](https://drive.google.com/file/d/1IqiuQlZLqzZWEcRJIzxQ0aLysmHm2DPK/view?usp=drive_link) ([transcript](https://docs.google.com/document/d/1GR-NynL_zOoewWV8e-pOeTvq1hwxjVYrYO8Di6SQFBQ/edit?usp=drive_link))
