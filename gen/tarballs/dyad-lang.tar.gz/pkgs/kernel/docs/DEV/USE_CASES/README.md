# Dyad GUI Use Cases

This is a collection of use cases for the Dyad GUI. This is largely just to
help developers understand the way component and system models would be
developed in Dyad.
