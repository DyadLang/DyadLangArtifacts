# Dyad Tutorial

Topics covered in this tutorial:

- [Creating the Simplest Possible Model](./SIMPLE.md)
- [Creating an Acausal Model](./ACAUSAL.md)
- [Code Reuse in Dyad](./EXTENDS.md)

As an "appendix", there is a [cheatsheet](./CHEATSHEET.md) that compares Dyad
and MTK syntax.
