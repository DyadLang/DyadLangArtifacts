---
icon: file-code-24
---

# Dyad Studio

The interactions with the Dyad GUI will be broken down into the following distinct section:

1. [Startup](./STARTUP.md)
2. [Dyad Code Activated](./ACTIVE.md)
