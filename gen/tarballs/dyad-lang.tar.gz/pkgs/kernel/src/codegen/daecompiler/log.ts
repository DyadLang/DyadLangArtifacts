import debug from "debug";
export const mtkLog = debug("codegen:mtk");
