import debug from "debug";
export const modLog = debug("codegen:modelica");
