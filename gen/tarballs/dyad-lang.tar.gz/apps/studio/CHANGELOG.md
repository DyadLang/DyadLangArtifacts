# Change Log

All notable changes to the "Dyad Studio" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

## [v0.1.3] - 2024-06-26

- Initial release
