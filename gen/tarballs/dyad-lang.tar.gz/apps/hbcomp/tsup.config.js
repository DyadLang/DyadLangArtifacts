export default {
    noExternal: [/(.*)/],
    minify: false,
};