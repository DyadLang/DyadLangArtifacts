# Origin

```
Package for simulating oil production
author: 	Bernt Lie
		    University of South-Eastern Norway
			October 3, 2022
```
