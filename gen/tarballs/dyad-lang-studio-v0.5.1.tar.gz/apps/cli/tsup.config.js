export default {
    noExternal: [/(.*)/],
    minify: true,
};
//# sourceMappingURL=tsup.config.js.map