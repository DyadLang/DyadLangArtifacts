export const baseLibraryName = "Dyad";
export const languageName = "Dyad";
export const uriScheme = "dyad";
export const fileExtension = "dyad";
export const sourceFolder = "dyad";
