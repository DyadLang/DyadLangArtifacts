
using BarComponents
using Test
    
include("../generated/tests.jl")