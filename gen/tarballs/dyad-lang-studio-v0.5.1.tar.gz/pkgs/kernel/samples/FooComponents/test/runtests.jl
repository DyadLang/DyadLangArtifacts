
using FooComponents
using Test
    
include("../generated/tests.jl")