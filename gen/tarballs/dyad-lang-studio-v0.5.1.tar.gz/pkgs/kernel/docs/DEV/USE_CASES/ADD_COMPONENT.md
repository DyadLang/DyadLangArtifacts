---
order: 95
icon: ":gear:"
---

# Adding a Component
