---
order: 80
icon: ":children_crossing:"
---

# Adding a Dependency
