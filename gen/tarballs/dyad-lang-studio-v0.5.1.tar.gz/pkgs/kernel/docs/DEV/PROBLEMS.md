---
order: 10
icon: ":man-shrugging:"
---

# Representing Problems
