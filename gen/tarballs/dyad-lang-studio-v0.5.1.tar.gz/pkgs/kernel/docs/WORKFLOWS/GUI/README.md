---
icon: browser-24
---

# Dyad GUI

The interactions with the Dyad GUI will be broken down into the following distinct section:

1. [Startup](./STARTUP.md)
2. [Application Opened](./OPENED.md)
