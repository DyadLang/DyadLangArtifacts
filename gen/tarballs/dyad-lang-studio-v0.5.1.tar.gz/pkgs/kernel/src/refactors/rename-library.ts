import { Problem } from "@juliacomputing/dyad-common";
import { Workspace } from "../workspace/index.js";

export function renameLibrary(
  _workspace: Workspace,
  _oldname: string,
  _newname: string
): Problem[] {
  throw new Error("Unimplemented");
}
