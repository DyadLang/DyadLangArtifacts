// FIXME: Change these to 1200?  Will give a more flexible grid (more factors)
export const viewWidth = 1000;
export const viewHeight = 1000;
