export interface DAECodeGenerationOptions {
}

export function normalizeDAECGOptions(
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  opts: Partial<DAECodeGenerationOptions>
): DAECodeGenerationOptions {
  return {
  };
}
