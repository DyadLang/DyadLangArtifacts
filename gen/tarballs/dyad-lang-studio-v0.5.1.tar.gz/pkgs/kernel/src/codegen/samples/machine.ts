export const machine_sources = {
  "machine.dyad": `model Machine1 begin
variable v::Int64
state state1 begin
    state stateX begin
    end
    state stateY begin 
    end 
    state stateA begin
    end
    state stateB begin 
    end 
    state stateC begin
    end
end
state state2 begin
end
transitions begin
end
end
`,
};
