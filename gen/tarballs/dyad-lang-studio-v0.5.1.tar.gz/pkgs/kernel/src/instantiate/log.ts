import debug from "debug";
export const astLog = debug("inst:ast");
export const instLog = debug("inst:inst");
