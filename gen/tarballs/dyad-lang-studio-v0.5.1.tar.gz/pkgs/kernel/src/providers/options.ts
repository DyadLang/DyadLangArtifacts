export interface SetOptions {
  skipReparse?: boolean;
}
