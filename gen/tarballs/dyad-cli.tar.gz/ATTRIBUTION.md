# Dyad CLI Bundle

This artifact contains the bundled Dyad CLI from dyad-lang at commit: d54fbed396ab4dd44a61ab1b499130330f69efbb

## Source
Repository: https://github.com/juliacomputing/dyad-lang.git
Commit: d54fbed396ab4dd44a61ab1b499130330f69efbb

## Usage
Run with Node.js: `node dyad-cli.js [command] [options]`

## License
Please refer to the LICENSE file in the dyad-lang repository for licensing information.
