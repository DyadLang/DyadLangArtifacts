# Dyad CLI Bundle

This artifact contains the bundled Dyad CLI from dyad-lang at commit: 8bb5dc3bbb3da156613d391f7def08f32d41b149

## Source
Repository: https://github.com/juliacomputing/dyad-lang.git
Commit: 8bb5dc3bbb3da156613d391f7def08f32d41b149

## Usage
Run with Node.js: `node dyad-cli.js [command] [options]`

## License
Please refer to the LICENSE file in the dyad-lang repository for licensing information.
